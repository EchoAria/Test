<?php
echo 'pong';