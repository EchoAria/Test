<?php

$options = array(
    'group'   => !empty($_GET['group']) ? $_GET['group'] : -1,
    'qq'   => !empty($_GET['qq']) ? $_GET['qq'] : -1,
    'mid'   => !empty($_GET['mid']) && is_numeric($_GET['mid']) ? 'm'.$_GET['mid'] : -1,
    'uname'  => !empty($_GET['uname']) ? $_GET['uname'] : 'undefined',
    'aid'   => !empty($_GET['aid']) && is_numeric($_GET['aid']) ? $_GET['aid'] : -1,
    'title'  => !empty($_GET['title']) ? $_GET['title'] : 'undefined',
    'pic'  => !empty($_GET['pic']) ? $_GET['pic'] : 'undefined',
    'length'   => !empty($_GET['length']) ? $_GET['length'] : -1,
    'created'   => !empty($_GET['created']) && is_numeric($_GET['created']) ? $_GET['created'] : -1,
);

$group_path = './group/';
$file_path = $group_path . $options['group'] . '.json';


$output = array(
    $options['mid'] => array(
        'qq' => $options['qq'],
        'mid' => $options['mid'],
        'uname' => $options['uname'],
        'aid' => $options['aid'],
        'title' => $options['title'],
        'pic' => $options['pic'],
        'length' => $options['length'],
        'created' => $options['created'],
    )
);



if(file_exists($file_path)){
    $_temp = file_get_contents($file_path);
    $_temp = json_decode($_temp, true);
    foreach($_temp as $k=>$v){
        if($v['qq'] == -1){
            unset($_temp[$k]);
        }
    }
    $output = array_merge($_temp, $output);
}

$output = json_encode($output, JSON_UNESCAPED_UNICODE);

file_put_contents($file_path, $output);

echo($output);