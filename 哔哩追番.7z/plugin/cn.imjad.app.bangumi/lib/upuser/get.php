<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

$options = array(
    'group'   => !empty($_GET['group']) ? $_GET['group'] : -1,
    'qq'   => !empty($_GET['qq']) ? $_GET['qq'] : -1,
);

$group_path = dirname(__FILE__).'/group/';
$file_path = $group_path . $options['group'] . '.json';

$_temp = file_get_contents($file_path);
$_temp = json_decode($_temp, true);

foreach($_temp as $k=>$v){
    if($v['qq'] == -1){
        unset($_temp[$k]);
    }
}

$output = array();

if($options['qq'] == -1){
    $output = $_temp;
}else{
    foreach($_temp as $k=>$v){
        $qqs = explode(",", $v['qq']);
        if(!in_array($options['qq'], $qqs)){
            unset($_temp[$k]);
        }
    }
    $output = $_temp;
}
header('Content-Type: application/json;charset=utf-8');
echo(json_encode($output, JSON_UNESCAPED_UNICODE));