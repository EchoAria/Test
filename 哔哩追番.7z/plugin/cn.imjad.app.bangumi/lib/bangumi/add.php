<?php

$options = array(
    'group'   => !empty($_GET['group']) ? $_GET['group'] : -1,
    'qq'   => !empty($_GET['qq']) ? $_GET['qq'] : -1,
    'season_id'   => !empty($_GET['season_id']) && is_numeric($_GET['season_id']) ? 's'.$_GET['season_id'] : -1,
    'bangumi_title'  => !empty($_GET['bangumi_title']) ? $_GET['bangumi_title'] : 'undefined',
    'jp_title'  => !empty($_GET['jp_title']) ? $_GET['jp_title'] : 'undefined',
    'av_id'   => !empty($_GET['av_id']) && is_numeric($_GET['av_id']) ? 'a'.$_GET['av_id'] : -1,
    'newest_ep_id'   => !empty($_GET['newest_ep_id']) ? $_GET['newest_ep_id'] : "0",
    'newest_ep_index'   => !empty($_GET['newest_ep_index']) ? $_GET['newest_ep_index'] : "0",
    'index_title'  => !empty($_GET['index_title']) ? $_GET['index_title'] : 'undefined',
    'cover'  => !empty($_GET['cover']) ? $_GET['cover'] : 'undefined',
    'webplay_url'  => !empty($_GET['webplay_url']) ? $_GET['webplay_url'] : 'undefined',
    'is_finish'  => !empty($_GET['is_finish']) ? $_GET['is_finish'] : 0,
);

$group_path = dirname(__FILE__).'/group/';
$file_path = $group_path . $options['group'] . '.json';


$output = array(
    $options['season_id'] => array(
        'qq' => $options['qq'],
        'season_id' => $options['season_id'],
        'bangumi_title' => $options['bangumi_title'],
        'jp_title' => $options['jp_title'],
        'av_id' => $options['av_id'],
        'newest_ep_id' => $options['newest_ep_id'],
        'newest_ep_index' => $options['newest_ep_index'],
        'index_title' => $options['index_title'],
        'cover' => $options['cover'],
        'webplay_url' => $options['webplay_url'],
        'is_finish' => $options['is_finish'],
    )
);



if(file_exists($file_path)){
    $_temp = file_get_contents($file_path);
    $_temp = json_decode($_temp, true);
    foreach($_temp as $k=>$v){
        if($v['qq'] == -1){
            unset($_temp[$k]);
        }
    }
    $output = array_merge($_temp, $output);
}

$output = json_encode($output, JSON_UNESCAPED_UNICODE);

if(!is_null($output)){
    file_put_contents($file_path, $output);
    
    echo($output);
}